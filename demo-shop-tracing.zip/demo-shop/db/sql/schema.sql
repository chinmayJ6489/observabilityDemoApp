CREATE TABLE products (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    category    TEXT NOT NULL,
    price       NUMERIC(10,2) NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE inventory (
    product_id INT PRIMARY KEY REFERENCES products(id),
    stock      INT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE orders (
    id         BIGSERIAL PRIMARY KEY,
    product_id INT NOT NULL REFERENCES products(id),
    quantity   INT NOT NULL,
    amount     NUMERIC(12,2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reviews (
    id         BIGSERIAL PRIMARY KEY,
    product_id INT NOT NULL REFERENCES products(id),
    author     TEXT NOT NULL,
    rating     SMALLINT NOT NULL,
    comment    TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL
);

INSERT INTO products (name, category, price, description)
SELECT (ARRAY['Classic','Pro','Ultra','Eco','Smart','Mini'])[1 + (g % 6)] || ' ' ||
       (ARRAY['Headphones','Backpack','Sneakers','Watch','Lamp','Keyboard','Mug','Jacket'])[1 + (g % 8)] || ' #' || g,
       (ARRAY['electronics','outdoor','apparel','home'])[1 + (g % 4)],
       round((5 + random() * 295)::numeric, 2),
       'Demo product number ' || g
FROM generate_series(1, 200) g;

INSERT INTO inventory (product_id, stock) SELECT id, 1000000 FROM products;

-- 2M reviews: large enough that losing the index causes painful sequential scans
INSERT INTO reviews (product_id, author, rating, comment, created_at)
SELECT 1 + (g % 200),
       'user' || (g % 5000),
       1 + (g % 5),
       'Review ' || md5(g::text),
       now() - (g || ' seconds')::interval
FROM generate_series(1, 2000000) g;

CREATE INDEX idx_reviews_product_created ON reviews (product_id, created_at DESC);
CREATE INDEX idx_orders_created ON orders (created_at DESC);

ANALYZE;
