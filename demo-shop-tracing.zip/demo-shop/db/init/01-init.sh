#!/bin/bash
set -euo pipefail

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -v shop_pw="$SHOP_DB_PASSWORD" <<'EOSQL'
CREATE USER shop WITH PASSWORD :'shop_pw';
ALTER DATABASE shop OWNER TO shop;
GRANT ALL ON SCHEMA public TO shop;
EOSQL

psql -v ON_ERROR_STOP=1 --username shop --dbname "$POSTGRES_DB" -f /sql/schema.sql
