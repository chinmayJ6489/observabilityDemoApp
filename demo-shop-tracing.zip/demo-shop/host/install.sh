#!/usr/bin/env bash
# Installs Demo Shop directly on a Linux host (Ubuntu 22.04/24.04 or Debian 12) as systemd services:
#   postgresql, shop-api (Python), shop-web (Node.js), shop-loadgen
# Usage: sudo bash host/install.sh [path/to/.env]     (defaults to <repo>/.env)
set -euo pipefail

APP_DIR=/opt/otel-demo-shop
CONF_DIR=/etc/otel-demo-shop
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_SRC="${1:-$REPO/.env}"

log() { printf '\033[1;36m[install]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "run as root: sudo bash $0"
command -v apt-get >/dev/null || die "only apt-based distros (Ubuntu/Debian) are supported"
[[ -f "$ENV_SRC" ]] || die "missing $ENV_SRC - copy .env.example to .env and fill it in"
ENV_CONTENT="$(sed 's/\r$//' "$ENV_SRC")" || die "cannot read $ENV_SRC"
set -a; . /dev/stdin <<< "$ENV_CONTENT"; set +a
unset ENV_CONTENT
[[ -n "${SHOP_DB_PASSWORD:-}" ]] || die "SHOP_DB_PASSWORD is missing or empty in $ENV_SRC"
[[ -n "${CHAOS_TOKEN:-}" ]] || die "CHAOS_TOKEN is missing or empty in $ENV_SRC"
TRACE_ENABLED="${TRACE_ENABLED:-false}"
case "$TRACE_ENABLED" in
  true) OTEL_SDK_DISABLED=false ;;
  false) OTEL_SDK_DISABLED=true ;;
  *) die "TRACE_ENABLED must be true or false" ;;
esac
cd /tmp

HOSTNAME_FQDN="$(hostname)"

# ------------------------------------------------------------------ packages
log "Installing OS packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq postgresql postgresql-contrib python3-venv python3-pip nodejs npm curl ca-certificates xz-utils logrotate >/dev/null

node_major="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/')"
if (( ${node_major:-0} < 18 )); then
  NODE_VERSION="${NODE_VERSION:-20.18.0}"
  case "$(dpkg --print-architecture)" in amd64) narch=x64 ;; arm64) narch=arm64 ;; *) die "unsupported arch" ;; esac
  log "Distro Node.js is too old (v${node_major:-none}); installing Node $NODE_VERSION into /usr/local"
  curl -fsSL "https://nodejs.org/dist/v${NODE_VERSION}/node-v${NODE_VERSION}-linux-${narch}.tar.xz" \
    | tar -xJ -C /usr/local --strip-components=1
  hash -r
fi

# ------------------------------------------------------------------ app user + code
id shop-app >/dev/null 2>&1 || useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin shop-app
mkdir -p "$APP_DIR"/{api,web,loadgen} "$CONF_DIR"

log "Deploying shop-api"
install -m 0644 "$REPO/api/main.py" "$REPO/api/requirements.txt" "$APP_DIR/api/"
[[ -d "$APP_DIR/api/app-venv" ]] || python3 -m venv "$APP_DIR/api/app-venv"
"$APP_DIR/api/app-venv/bin/pip" install -q --upgrade pip
"$APP_DIR/api/app-venv/bin/pip" install -q -r "$APP_DIR/api/requirements.txt"

log "Deploying shop-web"
install -m 0644 "$REPO/web/package.json" "$REPO/web/server.js" "$APP_DIR/web/"
(cd "$APP_DIR/web" && npm install --omit=dev --no-audit --no-fund --loglevel=error)

log "Deploying loadgen"
install -m 0755 "$REPO/loadgen/loadgen.sh" "$APP_DIR/loadgen/"
chown -R shop-app:shop-app "$APP_DIR"

# ------------------------------------------------------------------ postgres
log "Configuring PostgreSQL"
pg() { runuser -u postgres -- psql -v ON_ERROR_STOP=1 -qAt "$@"; }
pg -c "ALTER SYSTEM SET max_connections = 60;"
pg -c "ALTER SYSTEM SET log_min_duration_statement = 500;"
pg -c "ALTER SYSTEM SET track_io_timing = on;"
systemctl restart postgresql

pg -v pw="$SHOP_DB_PASSWORD" <<'SQL'
SELECT format('CREATE ROLE shop LOGIN PASSWORD %L', :'pw') WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'shop')
\gexec
SELECT format('ALTER ROLE shop PASSWORD %L', :'pw')
\gexec
SQL
if [[ -z "$(pg -c "SELECT 1 FROM pg_database WHERE datname = 'shop'")" ]]; then
  pg -c "CREATE DATABASE shop OWNER shop;"
fi
if [[ -z "$(PGPASSWORD="$SHOP_DB_PASSWORD" psql -h 127.0.0.1 -U shop -d shop -qAtc "SELECT to_regclass('public.products')")" ]]; then
  log "Loading schema and seed data (2M reviews, ~1 min)"
  PGPASSWORD="$SHOP_DB_PASSWORD" psql -h 127.0.0.1 -U shop -d shop -v ON_ERROR_STOP=1 -q -f "$REPO/db/sql/schema.sql"
fi

# ------------------------------------------------------------------ config files
log "Writing $CONF_DIR/shop.env"
umask 077
cat > "$CONF_DIR/shop.env" <<EOF
OTEL_SDK_DISABLED=${OTEL_SDK_DISABLED}
OTEL_TRACES_EXPORTER=otlp
OTEL_METRICS_EXPORTER=none
OTEL_LOGS_EXPORTER=none
OTEL_EXPORTER_OTLP_TRACES_PROTOCOL=grpc
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=http://127.0.0.1:19090
OTEL_RESOURCE_ATTRIBUTES=service.namespace=demo-shop
OTEL_PYTHON_DISABLED_INSTRUMENTATIONS=psycopg2
OTEL_NODE_DISABLED_INSTRUMENTATIONS=fs,dns,net
DB_HOST=127.0.0.1
DB_NAME=shop
DB_USER=shop
DB_PASSWORD=${SHOP_DB_PASSWORD}
SHOP_DB_PASSWORD=${SHOP_DB_PASSWORD}
CHAOS_TOKEN=${CHAOS_TOKEN}
WORKERS=${LOADGEN_WORKERS:-4}
PAUSE_SECONDS=${LOADGEN_PAUSE_SECONDS:-0.5}
EOF

umask 022

# ------------------------------------------------------------------ services
log "Installing systemd units"
install -d -o root -g adm -m 0750 /var/log/demo-shop
for logfile in /var/log/demo-shop/shop-api.log /var/log/demo-shop/shop-web.log; do
  touch "$logfile"
  chown root:adm "$logfile"
  chmod 0640 "$logfile"
done
install -m 0644 "$REPO/host/logrotate/demo-shop" /etc/logrotate.d/demo-shop
install -m 0644 "$REPO"/host/systemd/shop-*.service /etc/systemd/system/
mkdir -p /etc/systemd/system/shop-api.service.d /etc/systemd/system/shop-web.service.d
if [[ "$TRACE_ENABLED" == true ]]; then
  API_COMMAND='/opt/otel-demo-shop/api/app-venv/bin/opentelemetry-instrument /opt/otel-demo-shop/api/app-venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --no-access-log'
  WEB_COMMAND='/usr/bin/env node --require @opentelemetry/auto-instrumentations-node/register server.js'
else
  API_COMMAND='/opt/otel-demo-shop/api/app-venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --no-access-log'
  WEB_COMMAND='/usr/bin/env node server.js'
fi
cat > /etc/systemd/system/shop-api.service.d/20-otel-demo-mode.conf <<EOF
[Service]
ExecStart=
ExecStart=${API_COMMAND}
EOF
cat > /etc/systemd/system/shop-web.service.d/20-otel-demo-mode.conf <<EOF
[Service]
ExecStart=
ExecStart=${WEB_COMMAND}
EOF
systemctl daemon-reload
systemctl enable --now postgresql >/dev/null
for svc in shop-api shop-web shop-loadgen; do
  systemctl enable "$svc" >/dev/null
  systemctl restart "$svc"
done

sleep 5
services=(postgresql shop-api shop-web shop-loadgen)
for svc in "${services[@]}"; do
  printf '  %-16s %s\n' "$svc" "$(systemctl is-active "$svc" || true)"
done
log "Done. Shop UI: http://${HOSTNAME_FQDN}:3000"
log "Trace export enabled: ${TRACE_ENABLED} (local gRPC proxy: 127.0.0.1:19090)"
log "Application logs: /var/log/demo-shop/shop-api.log and /var/log/demo-shop/shop-web.log"
log "Faults: sudo bash scripts/inject.sh <scenario>  /  sudo bash scripts/remediate.sh <scenario|all>"
