'use strict';

const express = require('express');
const axios = require('axios');
const pino = require('pino');
const { randomUUID } = require('crypto');
const { trace } = require('@opentelemetry/api');

const PORT = Number(process.env.PORT || 3000);
const api = axios.create({
  baseURL: process.env.API_URL || 'http://api:8000',
  timeout: Number(process.env.API_TIMEOUT_MS || 10000),
});
const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  mixin() {
    const context = trace.getActiveSpan()?.spanContext();
    return context ? { trace_id: context.traceId, span_id: context.spanId } : {};
  },
});

const app = express();
app.use((req, res, next) => {
  const requestId = randomUUID().replace(/-/g, '');
  const started = process.hrtime.bigint();
  res.locals.requestId = requestId;
  res.setHeader('X-Request-ID', requestId);
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - started) / 1e6;
    const fields = { request_id: requestId, method: req.method, path: req.path,
      status_code: res.statusCode, duration_ms: Math.round(durationMs * 10) / 10 };
    if (res.statusCode >= 500) logger.error(fields, 'Request failed');
    else if (res.statusCode >= 400) logger.warn(fields, 'Request failed');
    else if (durationMs >= 1000) logger.warn(fields, 'Slow request');
  });
  next();
});
app.use(express.urlencoded({ extended: false }));

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const layout = (title, body) => `<!doctype html>
<html><head><meta charset="utf-8"><title>${esc(title)} - Demo Shop</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f5f6f8;color:#222}
 header{background:#01a982;color:#fff;padding:14px 24px;font-size:20px}
 header a{color:#fff;text-decoration:none}
 main{padding:24px;max-width:1100px;margin:auto}
 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
 .card{background:#fff;border-radius:8px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.1)}
 .price{font-weight:bold;color:#01a982}.err{background:#fde8e8;color:#9b1c1c}
 button{background:#01a982;color:#fff;border:0;padding:8px 16px;border-radius:4px;cursor:pointer}
</style></head>
<body><header><a href="/">Demo Shop</a></header><main>${body}</main></body></html>`;

function handleFailure(res, err, page) {
  const upstreamStatus = err.response?.status;
  logger.error({ request_id: res.locals.requestId, page, upstreamStatus, error: err.message, code: err.code }, 'Upstream shop-api request failed');
  const status = upstreamStatus && upstreamStatus < 500 ? upstreamStatus : 502;
  res.status(status).send(layout('Error', `<div class="card err"><h2>Something went wrong</h2>
    <p>The shop is having trouble right now (${esc(err.message)}). Please try again.</p></div>`));
}

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.get('/', async (_req, res) => {
  try {
    const { data } = await api.get('/api/products', { params: { limit: 24 }, headers: { 'X-Request-ID': res.locals.requestId } });
    logger.info({ products: data.length }, 'Rendered home page');
    const cards = data
      .map((p) => `<div class="card"><h3><a href="/product/${p.id}">${esc(p.name)}</a></h3>
        <div>${esc(p.category)}</div><div class="price">$${esc(p.price)}</div><small>${esc(p.stock)} in stock</small></div>`)
      .join('');
    res.send(layout('Home', `<div class="grid">${cards}</div>`));
  } catch (err) {
    handleFailure(res, err, 'home');
  }
});

app.get('/product/:id', async (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return res.status(400).send(layout('Bad request', '<p>Invalid product id</p>'));
  try {
    const { data: p } = await api.get(`/api/products/${id}`, { headers: { 'X-Request-ID': res.locals.requestId } });
    logger.info({ productId: id }, 'Rendered product page');
    const reviews = p.reviews.latest
      .map((r) => `<li>${'&#9733;'.repeat(r.rating)} <b>${esc(r.author)}</b>: ${esc(r.comment)}</li>`)
      .join('');
    res.send(layout(p.name, `<div class="card"><h2>${esc(p.name)}</h2><p>${esc(p.description)}</p>
      <p class="price">$${esc(p.price)}</p><p>${esc(p.stock)} in stock</p>
      <form method="post" action="/checkout">
        <input type="hidden" name="product_id" value="${p.id}">
        Qty <input type="number" name="quantity" value="1" min="1" max="10">
        <button type="submit">Buy now</button>
      </form>
      <h3>Reviews (${esc(p.reviews.count)}, avg ${esc(p.reviews.average)})</h3><ul>${reviews}</ul></div>`));
  } catch (err) {
    handleFailure(res, err, 'product');
  }
});

app.post('/checkout', async (req, res) => {
  const productId = Number.parseInt(req.body.product_id, 10);
  const quantity = Number.parseInt(req.body.quantity, 10);
  if (!Number.isInteger(productId) || !Number.isInteger(quantity)) {
    return res.status(400).send(layout('Bad request', '<p>Invalid order</p>'));
  }
  try {
    const { data } = await api.post('/api/orders', { product_id: productId, quantity }, { headers: { 'X-Request-ID': res.locals.requestId } });
    logger.info({ orderId: data.order_id, productId, quantity, amount: data.amount }, 'Checkout completed');
    res.status(201).send(layout('Thank you', `<div class="card"><h2>Order #${esc(data.order_id)} confirmed</h2>
      <p>Total: <span class="price">$${esc(data.amount)}</span></p><a href="/">Continue shopping</a></div>`));
  } catch (err) {
    handleFailure(res, err, 'checkout');
  }
});

app.listen(PORT, () => logger.info({ port: PORT }, 'shop-web listening'));
