import os
import json
import logging
import unittest
from unittest.mock import patch

os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("CHAOS_TOKEN", "test")

from fastapi import Request
from fastapi.responses import Response
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

from api.main import JsonFormatter, request_logging


def request(request_id=""):
    return Request({
        "type": "http",
        "method": "GET",
        "path": "/api/products",
        "headers": [(b"x-request-id", request_id.encode())],
        "query_string": b"secret=not-logged",
    })


class RequestLoggingTests(unittest.IsolatedAsyncioTestCase):
    async def test_slow_request_logs_duration_and_request_id(self):
        async def next_request(_request):
            return Response(status_code=200)

        with patch("api.main.time.monotonic", side_effect=[10, 11]), \
                self.assertLogs("shop-api", level="WARNING") as logs:
            response = await request_logging(request("a" * 32), next_request)
        record = logs.records[0]
        self.assertEqual(record.getMessage(), "Slow request")
        self.assertEqual(record.request_id, "a" * 32)
        self.assertEqual(record.duration_ms, 1000)
        self.assertEqual(record.path, "/api/products")
        self.assertEqual(response.headers["X-Request-ID"], "a" * 32)

    async def test_failed_response_logged_even_when_fast(self):
        async def next_request(_request):
            return Response(status_code=503)

        with patch("api.main.time.monotonic", side_effect=[10, 10.1]), \
                self.assertLogs("shop-api", level="ERROR") as logs:
            await request_logging(request(), next_request)
        self.assertEqual(logs.records[0].status_code, 503)
        self.assertEqual(logs.records[0].getMessage(), "Request failed")
        self.assertEqual(len(logs.records[0].request_id), 32)

    async def test_exception_is_logged_and_reraised(self):
        async def next_request(_request):
            raise RuntimeError("test failure")

        with patch("api.main.time.monotonic", side_effect=[10, 10.1]), \
                self.assertLogs("shop-api", level="ERROR") as logs:
            with self.assertRaisesRegex(RuntimeError, "test failure"):
                await request_logging(request(), next_request)
        self.assertEqual(logs.records[0].status_code, 500)
        self.assertIsNotNone(logs.records[0].exc_info)


class TraceLogTests(unittest.TestCase):
    def test_trace_context_is_included_only_when_active(self):
        record = logging.LogRecord("shop-api", logging.INFO, __file__, 1, "test", (), None)
        formatter = JsonFormatter()
        self.assertNotIn("trace_id", json.loads(formatter.format(record)))
        provider = TracerProvider()
        with provider.get_tracer("test").start_as_current_span("test") as span:
            data = json.loads(formatter.format(record))
            self.assertEqual(data["trace_id"], f"{span.get_span_context().trace_id:032x}")
            self.assertEqual(data["span_id"], f"{span.get_span_context().span_id:016x}")
        provider.shutdown()


if __name__ == "__main__":
    unittest.main()
