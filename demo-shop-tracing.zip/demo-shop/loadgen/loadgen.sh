#!/usr/bin/env bash
# Simulates shoppers: 40% browse home, 40% view a product, 20% checkout.
set -u

TARGET="${TARGET_URL:-http://web:3000}"
WORKERS="${WORKERS:-4}"
PAUSE="${PAUSE_SECONDS:-0.5}"

request() {
  local code
  code=$(curl -s -o /dev/null -m 15 -w '%{http_code}' "$@")
  [[ "$code" =~ ^[23] ]] || echo "$(date -u +%H:%M:%S) HTTP $code ${*: -1}"
}

worker() {
  while true; do
    local roll=$((RANDOM % 100)) pid=$((RANDOM % 200 + 1))
    if (( roll < 40 )); then
      request "$TARGET/"
    elif (( roll < 80 )); then
      request "$TARGET/product/$pid"
    else
      request -X POST -d "product_id=$pid&quantity=$((RANDOM % 3 + 1))" "$TARGET/checkout"
    fi
    sleep "$PAUSE"
  done
}

echo "loadgen: $WORKERS workers -> $TARGET"
for _ in $(seq "$WORKERS"); do worker & done
wait
