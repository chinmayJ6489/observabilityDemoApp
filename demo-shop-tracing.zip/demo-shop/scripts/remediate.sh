#!/usr/bin/env bash
# Remediate an injected failure scenario (or all of them).
# Usage: scripts/remediate.sh <scenario|all>
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

terminate_sessions() {
  local app="$1"
  local killed
  killed=$(psql_admin "SELECT count(pg_terminate_backend(pid)) FROM pg_stat_activity WHERE application_name = '$app';")
  log "Terminated $killed '$app' session(s)"
}

remediate() {
  case "$1" in
    api-latency)
      log "Removing injected latency from shop-api"
      chaos_api POST '{"latency_ms": 0, "latency_jitter_ms": 0}'
      ;;
    api-errors)
      log "Stopping injected shop-api errors"
      chaos_api POST '{"error_rate": 0}'
      ;;
    api-cpu)
      log "Stopping CPU burn threads in shop-api"
      chaos_api POST '{"cpu_threads": 0}'
      ;;
    api-memory)
      log "Stopping memory leak and releasing retained memory in shop-api"
      chaos_api POST '{"memory_leak_mb": 0, "release_memory": true}'
      ;;
    api-down)
      log "Starting shop-api"
      svc_start api
      wait_api
      ;;
    db-slow-query)
      log "Recreating index idx_reviews_product_created (CONCURRENTLY, no table lock)"
      psql_admin "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_reviews_product_created ON reviews (product_id, created_at DESC);"
      psql_admin "ANALYZE reviews;"
      ;;
    db-lock)
      log "Killing session holding the inventory lock"
      terminate_sessions chaos-lock
      ;;
    db-connections)
      log "Killing leaked idle connections"
      terminate_sessions chaos-conn
      ;;
    db-down)
      log "Starting postgres"
      svc_start postgres
      wait_postgres
      ;;
    host-cpu)
      is_host || return 0
      log "Killing noisy-neighbour CPU processes"
      if [[ -f /run/otel-demo-shop/host-cpu.pids ]]; then
        xargs -r kill < /run/otel-demo-shop/host-cpu.pids 2>/dev/null || true
        rm -f /run/otel-demo-shop/host-cpu.pids
      fi
      ;;
    *)
      echo "Usage: $0 <scenario|all>"
      usage_scenarios
      exit 1
      ;;
  esac
}

if [[ "${1:-}" == "all" ]]; then
  # infrastructure first, then in-process and DB-level faults
  remediate db-down
  remediate api-down
  for s in host-cpu api-latency api-errors api-cpu api-memory db-slow-query db-lock db-connections; do
    remediate "$s"
  done
else
  remediate "${1:-}"
fi

log "Remediation complete."
