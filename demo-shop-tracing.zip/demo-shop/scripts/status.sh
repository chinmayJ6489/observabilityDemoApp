#!/usr/bin/env bash
# Show current health and any active faults.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

if is_host; then
  log "Services on $(hostname)"
  for u in postgresql shop-api shop-web shop-loadgen; do
    printf '  %-16s %s\n' "$u" "$(systemctl is-active "$u" || true)"
  done
else
  log "Containers"
  "${COMPOSE[@]}" ps --format 'table {{.Service}}\t{{.State}}\t{{.Status}}'
fi

log "shop-api fault state"
curl -fsS -H "X-Chaos-Token: ${CHAOS_TOKEN}" "$API_URL/admin/chaos" && echo || echo "  shop-api unreachable"

log "Postgres"
if psql_admin "SELECT 1" >/dev/null 2>&1; then
  echo "  reviews index present : $(psql_admin "SELECT count(*) FROM pg_indexes WHERE indexname = 'idx_reviews_product_created';")"
  echo "  connections (total)   : $(psql_admin "SELECT count(*) FROM pg_stat_activity;")"
  echo "  chaos-lock sessions   : $(psql_admin "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'chaos-lock';")"
  echo "  chaos-conn sessions   : $(psql_admin "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'chaos-conn';")"
else
  echo "  postgres unreachable (or all connection slots in use)"
fi
