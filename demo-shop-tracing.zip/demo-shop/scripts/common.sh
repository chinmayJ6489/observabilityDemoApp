#!/usr/bin/env bash
# Shared helpers for inject.sh / remediate.sh / status.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

HOST_ENV=/etc/otel-demo-shop/shop.env
# host = installed by host/install.sh (systemd), docker = docker compose
DEPLOY_MODE="${DEPLOY_MODE:-$([[ -f $HOST_ENV ]] && echo host || echo docker)}"

if [[ "$DEPLOY_MODE" == host ]]; then
  [[ $EUID -eq 0 ]] || { echo "Host mode needs root: sudo bash $0 $*" >&2; exit 1; }
  set -a; . "$HOST_ENV"; set +a
else
  [[ -f .env ]] || { echo "Missing .env - run: cp .env.example .env" >&2; exit 1; }
  set -a; . ./.env; set +a
fi

API_URL="${API_URL:-http://localhost:8000}"
COMPOSE=(docker compose)
is_host() { [[ "$DEPLOY_MODE" == host ]]; }

log()  { printf '\033[1;36m[%s]\033[0m %s\n' "$(date -u +%H:%M:%SZ)" "$*"; }
hint() { printf '\033[1;33m  -> %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

require_int() { [[ "$1" =~ ^[0-9]+$ ]] || die "'$1' is not a positive integer"; }

chaos_api() {
  local method="$1" body="${2:-}"
  local args=(-fsS -X "$method" -H "X-Chaos-Token: ${CHAOS_TOKEN}" -H "Content-Type: application/json")
  [[ -n "$body" ]] && args+=(-d "$body")
  curl "${args[@]}" "$API_URL/admin/chaos" || die "shop-api admin endpoint not reachable at $API_URL"
  echo
}

# logical service: api | postgres
svc_stop() {
  if is_host; then systemctl stop "$(unit_of "$1")"; else "${COMPOSE[@]}" stop "$1"; fi
}
svc_start() {
  if is_host; then systemctl start "$(unit_of "$1")"; else "${COMPOSE[@]}" start "$1"; fi
}
unit_of() {
  case "$1" in api) echo shop-api ;; postgres) echo postgresql ;; *) die "unknown service $1" ;; esac
}

psql_admin() {
  if is_host; then
    (cd /tmp && runuser -u postgres -- psql -v ON_ERROR_STOP=1 -d shop -Atc "$1")
  else
    "${COMPOSE[@]}" exec -T postgres psql -v ON_ERROR_STOP=1 -U postgres -d shop -Atc "$1"
  fi
}

# Open <count> detached sessions as the app role, tagged with application_name so remediation can find them
pg_detached() {
  local app="$1" count="$2" sql="$3" i
  if is_host; then
    for ((i = 0; i < count; i++)); do
      PGAPPNAME="$app" PGPASSWORD="$SHOP_DB_PASSWORD" \
        setsid nohup psql -h 127.0.0.1 -U shop -d shop -qc "$sql" >/dev/null 2>&1 &
    done
  else
    "${COMPOSE[@]}" exec -d -T postgres sh -c \
      "for i in \$(seq 1 $count); do PGAPPNAME=$app psql -U shop -d shop -qc \"$sql\" >/dev/null 2>&1 & done; wait"
  fi
}

wait_for() {
  local name="$1" check="$2" tries=60
  log "Waiting for $name to become healthy..."
  until eval "$check" >/dev/null 2>&1; do
    ((tries--)) || die "$name did not become healthy"
    sleep 2
  done
  log "$name is healthy"
}

wait_api()      { wait_for "shop-api" "curl -fsS $API_URL/health"; }
wait_postgres() {
  if is_host; then
    wait_for "postgres" "pg_isready -h 127.0.0.1 -d shop"
  else
    wait_for "postgres" "${COMPOSE[*]} exec -T postgres pg_isready -h 127.0.0.1 -U postgres -d shop"
  fi
}

usage_scenarios() {
  cat <<EOF
Mode: $DEPLOY_MODE
Scenarios:
  Performance : api-latency [ms]   api-cpu [threads]   api-memory [mb_per_request]
  Availability: api-errors [rate]  api-down
  Database    : db-slow-query      db-lock [seconds]   db-connections [count]   db-down
  Host only   : host-cpu [procs]
EOF
}
