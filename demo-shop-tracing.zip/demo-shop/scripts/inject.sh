#!/usr/bin/env bash
# Inject a failure scenario into the demo shop.
# Usage: scripts/inject.sh <scenario> [param]
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

scenario="${1:-}"
param="${2:-}"

case "$scenario" in
  api-latency)
    ms="${param:-1500}"; require_int "$ms"
    log "PERFORMANCE: adding ~${ms}ms latency (+jitter) to every shop-api request"
    chaos_api POST "{\"latency_ms\": $ms, \"latency_jitter_ms\": $((ms / 3))}"
    hint "Requests to the shop will take longer to complete"
    ;;

  api-errors)
    rate="${param:-0.3}"
    [[ "$rate" =~ ^(0(\.[0-9]+)?|1(\.0+)?)$ ]] || die "rate must be between 0 and 1"
    log "AVAILABILITY: shop-api will fail ${rate} of requests with HTTP 500"
    chaos_api POST "{\"error_rate\": $rate}"
    hint "Logs: 'Inventory cache cluster unreachable' in shop-api and 'Upstream shop-api request failed' in shop-web"
    ;;

  api-cpu)
    threads="${param:-2}"; require_int "$threads"
    log "PERFORMANCE: starting $threads CPU-burning threads in shop-api"
    chaos_api POST "{\"cpu_threads\": $threads}"
    hint "CPU usage rises and requests may slow down"
    ;;

  api-memory)
    mb="${param:-1}"; require_int "$mb"
    log "PERFORMANCE/AVAILABILITY: shop-api retains ${mb}MB per request (leak). Memory limit is 512MB -> OOM kill"
    chaos_api POST "{\"memory_leak_mb\": $mb}"
    hint "Process memory grows until the OOM restart"
    hint "After OOM: brief outage, then counters reset (restarted by Docker / systemd)"
    ;;

  api-down)
    log "AVAILABILITY: stopping shop-api"
    svc_stop api
    hint "Logs: shop-web reports 'Upstream shop-api request failed' with a connection error"
    ;;

  db-slow-query)
    log "DATABASE: dropping index idx_reviews_product_created (2M-row reviews table -> sequential scans)"
    psql_admin "DROP INDEX IF EXISTS idx_reviews_product_created;"
    psql_admin "ANALYZE reviews;"
    hint "Product pages may take longer to load while PostgreSQL scans the reviews table"
    ;;

  db-lock)
    secs="${param:-600}"; require_int "$secs"
    log "DATABASE: holding EXCLUSIVE lock on 'inventory' for ${secs}s (blocks checkout writes, reads still work)"
    pg_detached chaos-lock 1 "BEGIN; LOCK TABLE inventory IN EXCLUSIVE MODE; SELECT pg_sleep($secs); COMMIT;"
    hint "Checkout waits for the lock and then fails; logs show a lock timeout"
    hint "Browsing still works -> partial outage only visible per-endpoint"
    ;;

  db-connections)
    n="${param:-57}"; require_int "$n"
    log "DATABASE: opening $n idle connections (max_connections=60) to exhaust the pool"
    pg_detached chaos-conn "$n" "SELECT pg_sleep(3600)"
    hint "Logs: 'FATAL: sorry, too many clients already' / 'remaining connection slots are reserved'"
    hint "Database connections from shop-api will fail when no slots are available"
    ;;

  db-down)
    log "DATABASE/AVAILABILITY: stopping postgres"
    svc_stop postgres
    hint "Database-backed API requests return 503 and shop-api logs a connection error"
    ;;

  host-cpu)
    is_host || die "host-cpu is only available in host mode"
    procs="${param:-$(nproc)}"; require_int "$procs"
    log "HOST: saturating $procs CPU core(s) on $(hostname) with a noisy-neighbour process"
    mkdir -p /run/otel-demo-shop
    for ((i = 0; i < procs; i++)); do
      setsid nohup sh -c 'exec yes >/dev/null' >/dev/null 2>&1 &
      echo $! >> /run/otel-demo-shop/host-cpu.pids
    done
    hint "Host CPU usage rises and services may slow down together"
    ;;

  *)
    echo "Usage: $0 <scenario> [param]"
    usage_scenarios
    exit 1
    ;;
esac

log "Injected '$scenario'. Remediate with: scripts/remediate.sh $scenario"
