import asyncio
import gc
import hmac
import json
import logging
import os
import random
import re
import sys
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional

import psycopg2
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from opentelemetry import trace
from opentelemetry.instrumentation.psycopg2 import Psycopg2Instrumentor
from opentelemetry.trace import Status, StatusCode
from pydantic import BaseModel, Field

if os.getenv("OTEL_SDK_DISABLED", "true").lower() == "false":
    Psycopg2Instrumentor().instrument(skip_dep_check=True)

tracer = trace.get_tracer("shop-api")

class JsonFormatter(logging.Formatter):
    def format(self, record):
        entry = {
            "timestamp": datetime.fromtimestamp(record.created, timezone.utc).isoformat(),
            "level": record.levelname,
            "service": "shop-api",
            "message": record.getMessage(),
        }
        for field in ("request_id", "method", "path", "status_code", "duration_ms"):
            if hasattr(record, field):
                entry[field] = getattr(record, field)
        context = trace.get_current_span().get_span_context()
        if context.is_valid:
            entry["trace_id"] = f"{context.trace_id:032x}"
            entry["span_id"] = f"{context.span_id:016x}"
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, ensure_ascii=True)


log = logging.getLogger("shop-api")
log.setLevel(logging.INFO)
log.propagate = False
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
log.addHandler(handler)

DB_PARAMS = dict(
    host=os.getenv("DB_HOST", "postgres"),
    port=int(os.getenv("DB_PORT", "5432")),
    dbname=os.getenv("DB_NAME", "shop"),
    user=os.getenv("DB_USER", "shop"),
    password=os.environ["DB_PASSWORD"],
    connect_timeout=3,
    application_name="shop-api",
    options="-c statement_timeout=8000 -c lock_timeout=6000",
)
CHAOS_TOKEN = os.environ["CHAOS_TOKEN"]

# ---------------------------------------------------------------- fault injection state
chaos = {"latency_ms": 0, "latency_jitter_ms": 0, "error_rate": 0.0, "cpu_threads": 0, "memory_leak_mb": 0}
_leaked: list[bytes] = []
_cpu_stop = threading.Event()
_cpu_workers: list[threading.Thread] = []


def _burn(stop: threading.Event) -> None:
    while not stop.is_set():
        sum(i * i for i in range(20000))


def _set_cpu_threads(n: int) -> None:
    global _cpu_stop
    _cpu_stop.set()
    for t in _cpu_workers:
        t.join(timeout=2)
    _cpu_workers.clear()
    _cpu_stop = threading.Event()
    for _ in range(n):
        t = threading.Thread(target=_burn, args=(_cpu_stop,), daemon=True)
        t.start()
        _cpu_workers.append(t)


# ---------------------------------------------------------------- db helpers


@contextmanager
def db():
    with tracer.start_as_current_span("shop.database.connect"):
        conn = psycopg2.connect(**DB_PARAMS)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_all(cur) -> list[dict]:
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


# ---------------------------------------------------------------- app
app = FastAPI(title="shop-api")


@app.exception_handler(psycopg2.Error)
async def db_error_handler(request: Request, exc: psycopg2.Error):
    span = trace.get_current_span()
    span.record_exception(exc)
    span.set_status(Status(StatusCode.ERROR, type(exc).__name__))
    log.error("Database error on %s %s: %s: %s", request.method, request.url.path,
              type(exc).__name__, str(exc).strip())
    return JSONResponse(status_code=503, content={"error": "database unavailable", "type": type(exc).__name__})


@app.middleware("http")
async def fault_middleware(request: Request, call_next):
    if not request.url.path.startswith("/api/"):
        return await call_next(request)

    if chaos["memory_leak_mb"] > 0:
        _leaked.append(b"x" * (chaos["memory_leak_mb"] * 1024 * 1024))

    if chaos["latency_ms"] > 0:
        delay = chaos["latency_ms"] + random.uniform(0, chaos["latency_jitter_ms"])
        with tracer.start_as_current_span("shop.injected_latency"):
            await asyncio.sleep(delay / 1000)

    if chaos["error_rate"] > 0 and random.random() < chaos["error_rate"]:
        exc = ConnectionError("Inventory cache cluster unreachable: connection reset by peer (redis-cache:6379)")
        span = trace.get_current_span()
        span.record_exception(exc)
        span.set_status(Status(StatusCode.ERROR, str(exc)))
        log.error("Request %s %s failed: %s", request.method, request.url.path, exc)
        return JSONResponse(status_code=500, content={"error": "internal error"})

    return await call_next(request)


@app.middleware("http")
async def request_logging(request: Request, call_next):
    supplied_id = request.headers.get("x-request-id", "")
    request_id = supplied_id if re.fullmatch(r"[a-f0-9]{32}", supplied_id) else uuid.uuid4().hex
    fields = {"request_id": request_id, "method": request.method, "path": request.url.path}
    started = time.monotonic()
    try:
        response = await call_next(request)
    except Exception:
        log.exception("Request failed", extra={**fields, "status_code": 500,
                                              "duration_ms": round((time.monotonic() - started) * 1000, 1)})
        raise
    duration_ms = round((time.monotonic() - started) * 1000, 1)
    fields.update(status_code=response.status_code, duration_ms=duration_ms)
    if response.status_code >= 500:
        log.error("Request failed", extra=fields)
    elif response.status_code >= 400:
        log.warning("Request failed", extra=fields)
    elif duration_ms >= 1000:
        log.warning("Slow request", extra=fields)
    response.headers["X-Request-ID"] = request_id
    return response


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/products")
def list_products(limit: int = 24):
    limit = max(1, min(limit, 200))
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT p.id, p.name, p.category, p.price, i.stock
               FROM products p JOIN inventory i ON i.product_id = p.id
               ORDER BY p.id LIMIT %s""",
            (limit,),
        )
        products = fetch_all(cur)
    log.info("Listed %d products", len(products))
    return products


@app.get("/api/products/{product_id}")
def get_product(product_id: int):
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT p.id, p.name, p.category, p.price, p.description, i.stock
               FROM products p JOIN inventory i ON i.product_id = p.id WHERE p.id = %s""",
            (product_id,),
        )
        rows = fetch_all(cur)
        if not rows:
            raise HTTPException(status_code=404, detail="product not found")
        product = rows[0]
        cur.execute("SELECT count(*), round(avg(rating)::numeric, 2) FROM reviews WHERE product_id = %s",
                    (product_id,))
        count, avg = cur.fetchone()
        cur.execute(
            """SELECT author, rating, comment, created_at FROM reviews
               WHERE product_id = %s ORDER BY created_at DESC LIMIT 5""",
            (product_id,),
        )
        product["reviews"] = {"count": count, "average": avg, "latest": fetch_all(cur)}
    log.info("Fetched product %s with %s reviews", product_id, count)
    return product


class OrderIn(BaseModel):
    product_id: int = Field(ge=1)
    quantity: int = Field(ge=1, le=10)


@app.post("/api/orders", status_code=201)
@tracer.start_as_current_span("shop.checkout")
def create_order(order: OrderIn):
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT p.price, i.stock
               FROM products p JOIN inventory i ON i.product_id = p.id
               WHERE p.id = %s FOR UPDATE OF i""",
            (order.product_id,),
        )
        row = cur.fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="product not found")
        price, stock = row
        if stock < order.quantity:
            raise HTTPException(status_code=409, detail="insufficient stock")
        cur.execute("UPDATE inventory SET stock = stock - %s, updated_at = now() WHERE product_id = %s",
                    (order.quantity, order.product_id))
        amount = price * order.quantity
        cur.execute("INSERT INTO orders (product_id, quantity, amount) VALUES (%s, %s, %s) RETURNING id",
                    (order.product_id, order.quantity, amount))
        order_id = cur.fetchone()[0]
    log.info("Order %s placed: product=%s qty=%s amount=%.2f", order_id, order.product_id, order.quantity, amount)
    return {"order_id": order_id, "product_id": order.product_id, "quantity": order.quantity, "amount": amount}


@app.get("/api/orders/recent")
def recent_orders():
    with db() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, product_id, quantity, amount, created_at FROM orders ORDER BY created_at DESC LIMIT 10")
        return fetch_all(cur)


# ---------------------------------------------------------------- admin (fault injection control)
class ChaosIn(BaseModel):
    latency_ms: Optional[int] = Field(None, ge=0, le=30000)
    latency_jitter_ms: Optional[int] = Field(None, ge=0, le=30000)
    error_rate: Optional[float] = Field(None, ge=0, le=1)
    cpu_threads: Optional[int] = Field(None, ge=0, le=8)
    memory_leak_mb: Optional[int] = Field(None, ge=0, le=50)
    release_memory: bool = False


def _authorize(token: Optional[str]) -> None:
    if not token or not hmac.compare_digest(token, CHAOS_TOKEN):
        raise HTTPException(status_code=401, detail="unauthorized")


def _state() -> dict:
    return {**chaos, "retained_memory_mb": round(sum(len(b) for b in _leaked) / 1048576, 1)}


@app.get("/admin/chaos")
def get_chaos(x_chaos_token: Optional[str] = Header(None)):
    _authorize(x_chaos_token)
    return _state()


@app.post("/admin/chaos")
def set_chaos(body: ChaosIn, x_chaos_token: Optional[str] = Header(None)):
    _authorize(x_chaos_token)
    changes = body.model_dump(exclude_none=True, exclude={"release_memory"})
    chaos.update(changes)
    if "cpu_threads" in changes:
        _set_cpu_threads(chaos["cpu_threads"])
    if body.release_memory:
        _leaked.clear()
        gc.collect()
    log.info("Runtime configuration updated: %s", changes)
    return _state()
