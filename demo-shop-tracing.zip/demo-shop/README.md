# Demo Shop

A three-tier demo shop with a web UI, API, PostgreSQL database and load generator. Scripts can inject and remediate performance, availability and database faults.

## Application architecture

The shop has three application tiers. The load generator acts like shoppers.

### Application requests

```mermaid
...
```

| Component | What it does | Connects to |
|---|---|---|
| Shopper / browser | Opens the shop, views products and places orders. | `shop-web` |
| Load generator | Continuously simulates browsing and checkouts to create traffic for the demo. | `shop-web` |
| `shop-web` | Serves the shop UI and forwards requests for data and checkout. | `shop-api` |
| `shop-api` | Handles shop operations, including product data and orders. | PostgreSQL |
| PostgreSQL | Stores shop data, such as products, reviews, inventory and orders. | `shop-api` |

Host tracing is optional. When enabled, automatic instrumentation creates web, API and PostgreSQL spans, with manual spans for checkout, database connection and injected latency. Traces go directly over plaintext OTLP/gRPC to an independently installed local trace proxy on `127.0.0.1:19090`. No collector is installed or configured by the application. Metrics and logs are not exported by this tracing configuration.

## Host installation

Supported systems: Ubuntu 22.04/24.04 or Debian 12 with systemd. The installer uses `apt`, installs PostgreSQL, Python and Node.js, changes PostgreSQL settings and restarts PostgreSQL. Use a dedicated demo machine with internet access.

```bash
cp .env.example .env
chmod 600 .env
# Edit .env and change SHOP_DB_PASSWORD and CHAOS_TOKEN to unique values.
sudo bash host/install.sh
```

The installer accepts LF or Windows CRLF line endings in `.env`. It sources this file as shell code, so use only a trusted file. Use alphanumeric passwords and token values to avoid shell quoting issues.

Open `http://<host>:3000`; allow TCP port 3000 only from trusted clients. The API listens on `127.0.0.1:8000`. Initial setup seeds two million reviews and may take a few minutes.

```bash
systemctl is-active postgresql shop-api shop-web shop-loadgen
curl -fsS http://127.0.0.1:3000/health
curl -fsS http://127.0.0.1:8000/api/products
sudo tail -n 100 /var/log/demo-shop/shop-api.log /var/log/demo-shop/shop-web.log
```

### Updating an existing host installation

Keep the existing `.env` and rerun `sudo bash host/install.sh` from the updated source folder. The installer reuses the database and preserves the existing `/opt/otel-demo-shop` and `/etc/otel-demo-shop` paths. It replaces this project's previous systemd startup overrides.

The installer does not stop, uninstall, or configure an existing collector or trace proxy. They may continue running independently; manage them separately according to your environment.

### Enable host tracing

Install and configure the OpsRamp trace proxy separately using your tenant's setup instructions. Confirm that its plaintext OTLP/gRPC listener is on this host at `127.0.0.1:19090`:

```bash
sudo systemctl status tracing-proxy --no-pager
sudo ss -ltnp | grep ':19090'
```

In the existing `.env`, set `TRACE_ENABLED=true`, then run `sudo bash host/install.sh` from the source folder. This restarts PostgreSQL and the application services. `TRACE_ENABLED` defaults to `false` if absent; set it to `false` and rerun the installer to disable tracing. The configured connection is plaintext and must not be used over an untrusted network.

Generate traffic by browsing the shop, then look for `shop-web` and `shop-api` in OpsRamp Traces. Check `/var/log/demo-shop/shop-api.log` and `/var/log/demo-shop/shop-web.log` for exporter errors. The proxy must be running and able to export upstream; installing it alone does not guarantee delivery. Tracing is host-only in this setup; Docker continues to run uninstrumented.

### Application logs

The host installer writes application output to `/var/log/demo-shop/shop-api.log` and `/var/log/demo-shop/shop-web.log`. They are owned by `root:adm` and readable with `sudo` or by members of `adm`. Service startup failures can also be inspected with `sudo journalctl -u shop-api -u shop-web`. Load generator logs remain in `journalctl -u shop-loadgen`; PostgreSQL logs are normally under `/var/log/postgresql/`.

Application records are JSON lines; runtime startup or uncaught-exception output may also be plain text. Failed requests (4xx/5xx) and successful requests taking at least 1000 ms have a severity, method, path, status, duration in milliseconds, and `request_id`. The web tier forwards the request ID to the API so matching request records can be searched across files; it is not a trace ID. When a span is active, application log entries also include `trace_id` and `span_id`; not every entry has an active span. Query strings, request bodies and authorization headers are not included in these request records. Other business/error logs may not contain a request ID.

Logs are rotated daily or above 50 MB when logrotate runs; seven rotations are retained, with older rotations compressed. Rotation uses `copytruncate`, which can lose lines written during copying. Configure your ingestion agent to read the two application files, handle rotation and parse JSON. This app does not configure ingestion or export logs.

```bash
sudo tail -f /var/log/demo-shop/shop-api.log /var/log/demo-shop/shop-web.log
sudo bash scripts/inject.sh api-latency 1500
# Browse the shop, then inspect the logs for "Slow request".
sudo bash scripts/remediate.sh api-latency
sudo bash scripts/inject.sh api-errors 1
# Browse the shop, then inspect the logs for "Request failed".
sudo bash scripts/remediate.sh api-errors
```

## Docker

```bash
cp .env.example .env
# Edit .env and change POSTGRES_PASSWORD, SHOP_DB_PASSWORD and CHAOS_TOKEN.
docker compose up -d --build
```

Shop UI: `http://localhost:8080`. Initial setup seeds two million reviews. Logs: `docker compose logs -f api web`.

## Fault scenarios

These scenarios affect the running demo. Use only on a dedicated test machine.

| Scenario | Effect |
|---|---|
| `api-latency [ms]` | Adds API request latency. |
| `api-cpu [threads]` | Starts CPU-burning threads. |
| `api-memory [mb]` | Retains memory on each request. |
| `api-errors [rate]` | Causes a fraction of API requests to fail. |
| `api-down` | Stops the API. |
| `db-slow-query` | Drops the reviews index. |
| `db-lock [secs]` | Holds an inventory lock, blocking checkout. |
| `db-connections [n]` | Opens connections to exhaust PostgreSQL slots. |
| `db-down` | Stops PostgreSQL. |
| `host-cpu [procs]` | Saturates CPU (host mode only). |

```bash
sudo bash scripts/inject.sh api-errors 0.3
sudo bash scripts/status.sh
sudo bash scripts/remediate.sh api-errors
sudo bash scripts/remediate.sh all
```

Use `bash` instead of `sudo bash` for Docker mode. `remediate.sh all` restarts stopped services and removes the demo faults.
